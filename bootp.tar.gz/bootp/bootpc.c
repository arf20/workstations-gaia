#include "bootp.h"

#define BOOTPC_SERVER_PORT 67
#define BOOTPC_CLIENT_PORT 68
#define BOOTPC_CIADDR U8TO32(192,168,1,2)
#define BOOTPC_CHADDR { 0x08, 0x00, 0x69, 0x09, 0x23, 0x6A }
#define BOOTPC_SNAME "studio"
#define BOOTPC_FILE "fx"

static unsigned long
bootpc_pkt(unsigned char *pkt, struct sockaddr_in *sin, char *scratch)
{
    static const char chaddr[] = BOOTPC_CHADDR;

    sin->sin_family = AF_INET;
    sin->sin_port = htons(BOOTPC_SERVER_PORT);
    sin->sin_addr.s_addr = INADDR_BROADCAST;
    
    memset(pkt, 0, BOOTP_Z);    
    BOOTP_OP_SET(pkt, BOOTP_BOOTREQUEST);
    BOOTP_HTYPE_SET(pkt, BOOTP_ETHERNET);
    BOOTP_HLEN_SET(pkt, 6);
    BOOTP_HOPS_SET(pkt, 0);
    BOOTP_XID_SET(pkt, 0x01020304);
    BOOTP_SECS_SET(pkt, 1);
    BOOTP_CIADDR_SET(pkt, BOOTPC_CIADDR);
    BOOTP_YIADDR_SET(pkt, 0);
    BOOTP_SIADDR_SET(pkt, 0);
    BOOTP_GIADDR_SET(pkt, 0);
    memcpy(BOOTP_CHADDR(pkt), chaddr, 6);
    strcpy(BOOTP_SNAME(pkt), BOOTPC_SNAME);
    strcpy(BOOTP_FILE(pkt), BOOTPC_FILE);
    return BOOTP_Z;
}

int
bootpc_io(int sock)
{
    struct sockaddr_in sin;
    socklen_t sin_len;
    unsigned long len, x;
    unsigned char pkt[1 << 12];
    char scratch[1024];

    // send packet
    len = bootpc_pkt(pkt, &sin, scratch);
    if(len == -1) return -1;
    printf("\nBOOTREQUEST dest=%s\n", bootp_sin_s(&sin, scratch));
    bootp_msg_printf(pkt, scratch);
    x = sendto(sock, pkt, len, 0, (struct sockaddr*)&sin, sizeof(sin));
    if(x != len) {
        if(x == -1) printf("[ERROR] %s, sendto failed\n", strerror(errno));
        else printf("[ERROR] %lu/%lu, sendto failed\n", x, len);
        return -1;
    }

    // recv packet
    sin_len = sizeof(sin);
    len = recvfrom(sock, pkt, sizeof(pkt), 0, (struct sockaddr*)&sin, &sin_len);
    if(len == BOOTP_Z) {
        if(sin_len == sizeof(sin)) {
            printf("\nBOOTREPLY src=%s\n", bootp_sin_s(&sin, scratch));
            bootp_msg_printf(pkt, scratch);
            return 0;
        } else printf("[ERROR] sockaddr length invalid, recvfrom failed\n");
    } else printf("[ERROR] %lu/%lu, recvfrom failed\n", len, BOOTP_Z);
    return -1;
}

int
main(int argc, char **argv)
{
    int retval, sock, i;
    struct sockaddr_in sin;

    // unbuffered mode
    setbuf(stdout, NULL);
    setbuf(stderr, NULL);

    // open socket
    retval = -1;
    sock = socket(PF_INET, SOCK_DGRAM, 0);
    if(sock != -1) {

        // enable send and receive of broadcast address
        i = 1;
        if(! setsockopt(sock, SOL_SOCKET, SO_BROADCAST, &i, sizeof(i))) {

            // bind to server port
            sin.sin_family = AF_INET;
            sin.sin_port = htons(BOOTPC_CLIENT_PORT);
            sin.sin_addr.s_addr = 0;
            if(! bind(sock, (struct sockaddr*)&sin, sizeof(sin))) {
                
                // main loop
                retval = bootpc_io(sock);

            } else printf("[ERROR] %s, bind failed\n", strerror(errno));
        } else printf("[ERROR] %s, SO_BROADCAST failed\n", strerror(errno));
        close(sock);
    } else printf("[ERROR] %s, socket failed\n", strerror(errno));
    return retval;
}
