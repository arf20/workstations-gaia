#ifndef BOOTP_H
#define BOOTP_H

// -----------------------------------------------------------------
// bootp (RFC 951) common library defines and functions
// -----------------------------------------------------------------

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>

#include <errno.h>
#include <stdio.h>
#include <string.h>

#define BOOTP_BOOTREQUEST 1
#define BOOTP_BOOTREPLY 2

#define BOOTP_ETHERNET 1

#define CSTR(x,off) ((unsigned char*)(x) + (off))

#define WORD_1(x,off) (CSTR(x,off)[0])
#define WORD_2(x,off) ((CSTR(x,off)[0] << 8) | (CSTR(x,off)[1]))
#define WORD_4(x,off) ((CSTR(x,off)[0] << 24) | (CSTR(x,off)[1] << 16) | \
                       (CSTR(x,off)[2] << 8) | (CSTR(x,off)[3]))

#define WORD_1_SET(x,off,val) (CSTR(x,off)[0] = (val))
#define WORD_2_SET(x,off,val) do {                  \
        CSTR(x,off)[0] = ((val) >> 8) & 0xFF;       \
        CSTR(x,off)[1] = (val) & 0xFF;              \
    } while(0)
#define WORD_4_SET(x,off,val) do {                   \
        CSTR(x,off)[0] = ((val) >> 24) & 0xFF;       \
        CSTR(x,off)[1] = ((val) >> 16) & 0xFF;       \
        CSTR(x,off)[2] = ((val) >> 8) & 0xFF;        \
        CSTR(x,off)[3] = (val) & 0xFF;               \
    } while(0)

#define U8TO32(a3,a2,a1,a0) ((a3) << 24 | (a2) << 16 | (a1) << 8 | (a0))

// get macros

#define BOOTP_OP(x) WORD_1(x,0)
#define BOOTP_HTYPE(x) WORD_1(x,1)
#define BOOTP_HLEN(x) WORD_1(x,2)
#define BOOTP_HOPS(x) WORD_1(x,3)
#define BOOTP_XID(x) WORD_4(x,4)
#define BOOTP_SECS(x) WORD_2(x,8)
// unused 2 bytes
#define BOOTP_CIADDR(x) WORD_4(x,12)
#define BOOTP_YIADDR(x) WORD_4(x,16)
#define BOOTP_SIADDR(x) WORD_4(x,20)
#define BOOTP_GIADDR(x) WORD_4(x,24)
#define BOOTP_CHADDR(x) CSTR(x,28)
#define BOOTP_CHADDR_Z 16
#define BOOTP_SNAME(x) CSTR(x,44) // nul-terminated
#define BOOTP_SNAME_Z 64
#define BOOTP_FILE(x) CSTR(x,108) // nul-terminated
#define BOOTP_FILE_Z 128
#define BOOTP_VEND(x) CSTR(x,236)
#define BOOTP_VEND_Z 64
#define BOOTP_Z 300

// set macros

#define BOOTP_OP_SET(x,val) WORD_1_SET(x,0,val)
#define BOOTP_HTYPE_SET(x,val) WORD_1_SET(x,1,val)
#define BOOTP_HLEN_SET(x,val) WORD_1_SET(x,2,val)
#define BOOTP_HOPS_SET(x,val) WORD_1_SET(x,3,val)
#define BOOTP_XID_SET(x,val) WORD_4_SET(x,4,val)
#define BOOTP_SECS_SET(x,val) WORD_2_SET(x,8,val)
#define BOOTP_CIADDR_SET(x,val) WORD_4_SET(x,12,val)
#define BOOTP_YIADDR_SET(x,val) WORD_4_SET(x,16,val)
#define BOOTP_SIADDR_SET(x,val) WORD_4_SET(x,20,val)
#define BOOTP_GIADDR_SET(x,val) WORD_4_SET(x,24,val)

// pretty print helpers

inline static char *
bootp_op_s(unsigned int x)
{
    switch(x) {
    case BOOTP_BOOTREQUEST: return "BOOTREQUEST";
    case BOOTP_BOOTREPLY: return "BOOTREPLY";
    }
    return NULL;
}

inline static char *
bootp_htype_s(unsigned int x)
{
    switch(x) {
    case BOOTP_ETHERNET: return "ETHERNET";
    }
    return NULL;
}

inline static char *
bootp_addr_s(unsigned int x, char *dest)
{
    sprintf(dest, "%u.%u.%u.%u", (x >> 24) & 0xFF, (x >> 16) & 0xFF, (x >> 8) & 0xFF, x & 0xFF);
    return dest;
}

inline static char *
bootp_chaddr_s(unsigned char *x, unsigned int hlen, char *dest)
{
    unsigned char *x1;
    char *d;

    if(hlen > 16) hlen = 16;
    x1 = x + hlen;
    d = dest;
    if(x < x1) {
    loop:
        d += sprintf(d, "%.2x", *x);
        ++x;
        if(x < x1) {
            *(d++) = ':';
            goto loop;
        }
    }
    return dest;
}

inline static char *
bootp_raw_16_s(unsigned char *x, char *dest)
{
    sprintf(dest, "%.2x%.2x%.2x%.2x %.2x%.2x%.2x%.2x %.2x%.2x%.2x%.2x %.2x%.2x%.2x%.2x    %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c %c",
            x[0], x[1], x[2], x[3],
            x[4], x[5], x[6], x[7],
            x[8], x[9], x[10], x[11],
            x[12], x[13], x[14], x[15],
            x[0], x[1], x[2], x[3],
            x[4], x[5], x[6], x[7],
            x[8], x[9], x[10], x[11],
            x[12], x[13], x[14], x[15]);
    return dest;
}

inline static char *
bootp_sin_s(struct sockaddr_in *sin, char *dest)
{
    sprintf(dest, "%u.%u.%u.%u:%u",
            ((unsigned char*)&sin->sin_addr)[0],
            ((unsigned char*)&sin->sin_addr)[1],
            ((unsigned char*)&sin->sin_addr)[2],
            ((unsigned char*)&sin->sin_addr)[3],
            ntohs(sin->sin_port));
    return dest;
}

void
bootp_msg_printf(unsigned char *x, char *scratch);

#endif
