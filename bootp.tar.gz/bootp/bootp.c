#include "bootp.h"

void
bootp_msg_printf(unsigned char *x, char *scratch)
{
    printf("op: %u[%s]\n", BOOTP_OP(x), bootp_op_s(BOOTP_OP(x)));
    printf("htype: %u[%s]\n", BOOTP_HTYPE(x), bootp_htype_s(BOOTP_HTYPE(x)));
    printf("hlen: %u\n", BOOTP_HLEN(x));
    printf("hops: %u\n", BOOTP_HOPS(x));
    printf("xid: %.8x\n", BOOTP_XID(x));
    printf("secs: %u\n", BOOTP_SECS(x));
    printf("ciaddr: %s\n", bootp_addr_s(BOOTP_CIADDR(x), scratch));
    printf("yiaddr: %s\n", bootp_addr_s(BOOTP_YIADDR(x), scratch));
    printf("siaddr: %s\n", bootp_addr_s(BOOTP_SIADDR(x), scratch));
    printf("giaddr: %s\n", bootp_addr_s(BOOTP_GIADDR(x), scratch));
    printf("chaddr: %s\n", bootp_chaddr_s(BOOTP_CHADDR(x), BOOTP_HLEN(x),
                                          scratch));
    printf("sname: %.64s\n", BOOTP_SNAME(x));
    printf("file: %.128s\n", BOOTP_FILE(x));
    printf("vend:\n");
    printf("    %s\n", bootp_raw_16_s(BOOTP_VEND(x), scratch));
    printf("    %s\n", bootp_raw_16_s(BOOTP_VEND(x) + 16, scratch));
    printf("    %s\n", bootp_raw_16_s(BOOTP_VEND(x) + 32, scratch));
}
