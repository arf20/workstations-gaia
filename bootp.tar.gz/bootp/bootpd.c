#include "bootp.h"

#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
        
#define FILECMP(src,str) memcmp((src), str, sizeof(str))

// -----------------------------------------------------------------
// configuration
// -----------------------------------------------------------------

#define BOOTPD_SERVER_PORT 67
#define BOOTPD_SIADDR U8TO32(192,168,1,1)
#define BOOTPD_CHROOT "/home/sgi"

static char *
bootpd_file(char *path)
{
    struct stat st;
    
    if(! FILECMP(path, "/fx")) return "/o1/stand/fx.ARCS";
    else if(! stat(path, &st)) return path;
    else return NULL;
}

// -----------------------------------------------------------------
// bootpd_pkt:
//
// When called, pkt contains the UDP payload of the BOOTREQUEST packet, and sin contains
// its source address.
//
// The function checks the packet. If a reply should be sent it
// modifies pkt to become a BOOTREPLY packet, modifies sin to be
// the destination address of the reply, and returns the length of the
// reply packet. If no reply should be sent, it returns -1.
// -----------------------------------------------------------------

static unsigned long
bootpd_pkt(unsigned char *pkt, struct sockaddr_in *sin, char *scratch)
{
    unsigned int addr;
    unsigned char *file0, *file1;

    // leave sin alone (send packet back to src of recvd packet)
    // note this assumes client sets its own IP
  
    BOOTP_OP_SET(pkt, BOOTP_BOOTREPLY);

    if(addr = BOOTP_CIADDR(pkt)) {
        BOOTP_YIADDR_SET(pkt, addr);
    } else {
        printf("    [ERROR] ciaddr == 0\n");
        return -1;
    }
    
    BOOTP_SIADDR_SET(pkt, BOOTPD_SIADDR);
    
    if(file1 = bootpd_file(file0 = BOOTP_FILE(pkt))) {
        if(strlen(file1) < BOOTP_FILE_Z) {
            strcpy(file0, file1);
        } else {
            printf("[ERROR] file too long\n");
            return -1;
        }
    } else {
        printf("[ERROR] file not found\n");
        return -1;
    }
    
    return BOOTP_Z;
}

// -----------------------------------------------------------------
// bootpd_io:
//
// main loop: receive request packet, process packet, send reply packet
// -----------------------------------------------------------------

static int
bootpd_io(int sock)
{
    struct sockaddr_in sin;
    socklen_t sin_len;
    unsigned long len, x;
    unsigned char pkt[1 << 12];
    char scratch[1024];

 loop:
    // recv packet
    sin_len = sizeof(sin);
    len = recvfrom(sock, pkt, sizeof(pkt), 0,
                   (struct sockaddr*)&sin, &sin_len);
    if(len == BOOTP_Z) {
        if(sin_len == sizeof(sin)) {
            printf("\nBOOTREQUEST src=%s\n", bootp_sin_s(&sin, scratch));
            bootp_msg_printf(pkt, scratch);

            // generate reply
            len = bootpd_pkt(pkt, &sin, scratch);
            if(len != -1) {
                printf("\nBOOTREPLY dest=%s\n", bootp_sin_s(&sin, scratch));
                bootp_msg_printf(pkt, scratch);

                // send reply
                x = sendto(sock, pkt, len, 0,
                           (struct sockaddr*)&sin, sizeof(sin));
                if(x != len) {
                    if(x == -1) printf("[ERROR] %s, sendto failed\n",
                                       strerror(errno));
                    else printf("[ERROR] %lu/%lu, sendto failed\n", x, len);
                    return -1;
                }
            }
        } else printf("[ERROR] BOOTREQUEST sin_len=%u\n", sin_len);
    }
    else if(len == -1) {
        printf("[ERROR] %s, recvfrom failed\n", strerror(errno));
        return -1;
    }
    goto loop;
}

// -----------------------------------------------------------------
// main:
//
// initialize chroot environment, socket, call main loop
// -----------------------------------------------------------------

int
main(int argc, char **argv)
{
    int retval, sock, i;
    struct sockaddr_in sin;

    retval = -1;

    // unbuffered mode
    setbuf(stdout, NULL);
    setbuf(stderr, NULL);

    // chroot
    if(! chroot(BOOTPD_CHROOT)) {
            
        // open socket
        sock = socket(PF_INET, SOCK_DGRAM, 0);
        if(sock != -1) {
            
            // enable send and receive of broadcast address
            i = 1;
            if(! setsockopt(sock, SOL_SOCKET, SO_BROADCAST,
                            &i, sizeof(i))) {
                    
                // bind to server port
                sin.sin_family = AF_INET;
                sin.sin_port = htons(BOOTPD_SERVER_PORT);
                sin.sin_addr.s_addr = 0;
                if(! bind(sock, (struct sockaddr*)&sin, sizeof(sin))) {
                    
                    // main loop
                    retval = bootpd_io(sock);
                    
                } else printf("[ERROR] %s, bind failed\n",
                              strerror(errno));
            } else printf("[ERROR] %s, SO_BROADCAST failed\n",
                          strerror(errno));
            close(sock);
        } else printf("[ERROR] %s, socket failed\n", strerror(errno));
    } else printf("[ERROR] %s, chroot failed\n", strerror(errno));
    return retval;
}
